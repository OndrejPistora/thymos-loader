"""
This module contains functions that should only be called when running the
frozen form of the app.
"""

from os.path import dirname, join, pardir
from fbs_runtime.platform import is_mac

import sys

PUBLIC_SETTINGS = None

def get_resource_dirs():
    app_dir = dirname(sys.executable)
    return [join(app_dir, pardir, 'Resources') if is_mac() else app_dir]

def load_public_settings():
    if PUBLIC_SETTINGS is None:
        raise RuntimeError(
            'Settings have not yet been initialized by PyInstaller runtime hook'
        )
    return PUBLIC_SETTINGS