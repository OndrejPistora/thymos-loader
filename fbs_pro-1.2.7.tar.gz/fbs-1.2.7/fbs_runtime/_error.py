# The motivation for keeping this class in a separate file is to avoid circular
# imports. Code inside fbs_runtime should import it from here. Other code should
# import it from fbs_runtime.
class FbsError(Exception):
    pass