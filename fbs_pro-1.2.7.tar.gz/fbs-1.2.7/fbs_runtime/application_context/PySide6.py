from . import _ApplicationContext, _QtBinding, cached_property
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication
from PySide6.QtNetwork import QAbstractSocket

class ApplicationContext(_ApplicationContext):
    @cached_property
    def _qt_binding(self):
        return _QtBinding(QApplication, QIcon, QAbstractSocket)