from fbs import path, SETTINGS
from fbs.builtin_commands import require_existing_project
from fbs.cmdline import command
from fbs.resources import _copy
from fbs_runtime import FbsError
from fbs_runtime._source import default_path
from os import listdir
from os.path import exists, join
from shutil import rmtree
from subprocess import run, CalledProcessError, PIPE

import fbs
import logging

__all__ = ['buildvm', 'runvm']

_LOG = logging.getLogger(__name__)

@command
def buildvm(name):
    """
    Build a Linux VM. Eg.: buildvm ubuntu
    """
    require_existing_project()
    src_root = 'src/build/docker'
    available_vms = set(listdir(default_path(src_root)))
    if exists(path(src_root)):
        available_vms.update(listdir(path(src_root)))
    if name not in available_vms:
        raise FbsError(
            'Could not find %s. Available VMs are:%s' %
            (name, ''.join(['\n * ' + vm for vm in available_vms]))
        )
    _check_gpg_keys_exist()
    if not exists(path('requirements/base.txt')):
        fbs_version = fbs.__version__
        raise FbsError(
            'Please list your Python dependencies in requirements/base.txt.\n'
            'For example:\n\n'
           f'    fbs@https://build-system.fman.io/pro/abcdef-.../{fbs_version}\n'
            '    PySide6==6.4.3\n\n'
            'The first line requires an fbs Pro edition with multiple '
            'downloads.\n'
            "If you don't have this, copy fbs_pro.tar.gz into requirements/ "
            "and\nadd its name to base.txt."
        )
    build_dir = path('target/%s-docker-image' % name)
    if exists(build_dir):
        rmtree(build_dir)
    src_dir = src_root + '/' + name
    for path_fn in default_path, path:
        _copy(path_fn, src_dir, build_dir)
    settings = SETTINGS['docker_images'].get(name, {})
    for path_fn in default_path, path:
        for p in settings.get('build_files', []):
            _copy(path_fn, p, join(build_dir, p))
    args = ['build', '--pull', '-t', _get_docker_id(name), build_dir]
    for arg, value in settings.get('build_args', {}).items():
        args.extend(['--build-arg', '%s=%s' % (arg, value)])
    try:
        _run_docker(
            args, check=True, stdout=PIPE, stderr=PIPE,
            universal_newlines=True
        )
    except CalledProcessError as e:
        raise FbsError(e.stdout + '\n' + e.stderr)
    _LOG.info('Done. You can now execute:\n    fbs runvm ' + name)

def _check_gpg_keys_exist():
    # All our Dockerfiles currently ADD public-key.gpg and private-key.gpg.
    # So give a nice error message in case they don't exist, instead of
    # unreadable Docker output.
    for gpg_file in ('public-key.gpg', 'private-key.gpg'):
        gpg_path = 'src/sign/linux/' + gpg_file
        if not exists(path(gpg_path)):
            message = f'Could not find {gpg_path}. Maybe you want to ' \
                      'run:\n    fbs gengpgkey'
            raise FbsError(message)

@command
def runvm(name):
    """
    Run a Linux VM. Eg.: runvm ubuntu
    """
    args = ['run', '-it']
    for item in _get_docker_mounts(name).items():
        args.extend(['-v', '%s:%s' % item])
    docker_id = _get_docker_id(name)
    args.append(docker_id)
    try:
        _run_docker(args, stderr=PIPE, universal_newlines=True, check=True)
    except CalledProcessError as e:
        if 'Unable to find image' in e.stderr:
            raise FbsError(
                'Docker could not find image %s. You may want to run:\n'
                '    fbs buildvm %s' % (docker_id, name)
            )

def _run_docker(args, **kwargs):
    try:
        return run(['docker'] + args, **kwargs)
    except FileNotFoundError:
        raise FbsError(
            'fbs could not find Docker. Is it installed and on your PATH?'
        )

def _get_docker_id(name):
    prefix = SETTINGS['app_name'].replace(' ', '_').lower()
    suffix = name.lower()
    return prefix + '/' + suffix

def _get_docker_mounts(name):
    result = {'target/' + name.lower(): 'target'}
    # These directories are created inside the container by `buildvm`:
    ignore = {'target', 'venv'}
    for file_name in listdir(path('.')):
        if file_name in ignore:
            continue
        result[file_name] = file_name
    path_in_docker = lambda p: '/root/%s/%s' % (SETTINGS['app_name'], p)
    return {path(src): path_in_docker(dest) for src, dest in result.items()}

def _get_settings(name):
    return SETTINGS['docker_images'][name]