from fbs import path, SETTINGS
from fbs_runtime import FbsError
from os import makedirs
from os.path import join, splitext, dirname, basename, exists
from shutil import copy
from subprocess import call, run, DEVNULL

import hashlib
import json
import os

_CERTIFICATE_PATH = 'src/sign/windows/certificate.pfx'
_TO_SIGN = ('.exe', '.cab', '.dll', '.ocx', '.msi', '.xpi')

def sign_windows():
    for subdir, _, files in os.walk(path('${freeze_dir}')):
        for file_ in files:
            extension = splitext(file_)[1]
            if extension in _TO_SIGN:
                sign_file(join(subdir, file_))

def sign_file(file_path, description='', url=''):
    helper = _SignHelper.instance()
    if not helper.is_signed(file_path):
        helper.sign(file_path, description, url)

class _SignHelper:

    _INSTANCE = None

    @classmethod
    def instance(cls):
        if cls._INSTANCE is None:
            cls._INSTANCE = cls(path('cache/signed'))
        return cls._INSTANCE

    def __init__(self, cache_dir):
        self._cache_dir = cache_dir

    def is_signed(self, file_path):
        return not call(
            ['signtool', 'verify', '/pa', file_path], stdout=DEVNULL,
            stderr=DEVNULL
        )

    def sign(self, file_path, description, url):
        json_path = self._get_json_path(file_path)
        try:
            with open(json_path) as f:
                cached = json.load(f)
            is_in_cache = description == cached['description'] and \
                          url == cached['url'] and \
                          self._hash(file_path) == cached['hash']
        except FileNotFoundError:
            is_in_cache = False
        if not is_in_cache:
            self._sign(file_path, description, url)
        copy(self._get_path_in_cache(file_path), file_path)

    def _sign(self, file_path, description, url):
        path_in_cache = self._get_path_in_cache(file_path)
        makedirs(dirname(path_in_cache), exist_ok=True)
        copy(file_path, path_in_cache)
        hash_ = self._hash(path_in_cache)
        _run_signtool(path_in_cache, retries=5)
        with open(self._get_json_path(file_path), 'w') as f:
            json.dump({
                'description': description,
                'url': url,
                'hash': hash_
            }, f)

    def _get_json_path(self, file_path):
        return self._get_path_in_cache(file_path) + '.json'

    def _get_path_in_cache(self, file_path):
        return join(self._cache_dir, basename(file_path))

    def _hash(self, file_path):
        bufsize = 65536
        hasher = hashlib.md5()
        with open(file_path, 'rb') as f:
            buf = f.read(bufsize)
            while buf:
                hasher.update(buf)
                buf = f.read(bufsize)
        return hasher.hexdigest()

def _run_signtool(file_path, retries=0, sec_between_retries=10):
    args = ['signtool', 'sign', '/as', '/fd', 'sha256', '/td', 'sha256']
    if exists(path(_CERTIFICATE_PATH)):
        try:
            password = SETTINGS['windows_sign_pass']
        except KeyError:
            raise FbsError(
                "You have %s but 'windows_sign_pass' is not set. Please either "
                "delete %s or set 'windows_sign_pass' to its password in "
                "src/build/settings/secret.json."
                % (_CERTIFICATE_PATH, _CERTIFICATE_PATH)
            ) from None
        else:
            args.extend(['/f', path(_CERTIFICATE_PATH), '/p', password])
    else:
        if 'windows_sign_pass' in SETTINGS:
            raise FbsError(
                "You have 'windows_sign_pass' in settings but %s does not "
                "exist. Please remove 'windows_sign_pass' from settings or "
                "create %s." % (_CERTIFICATE_PATH, _CERTIFICATE_PATH)
            ) from None
        try:
            subject = SETTINGS['windows_sign_subject']
        except KeyError:
            raise FbsError(
                "Please specify the certificate by either: 1) Creating %s and "
                "setting 'windows_sign_pass' in src/build/settings/secret.json "
                "or 2) setting 'windows_sign_subject' in "
                "src/build/settings/windows.json." % _CERTIFICATE_PATH
            )
        else:
            args.extend(['/n', subject])
    try:
        server = SETTINGS['windows_sign_server']
    except KeyError:
        pass
    else:
        args.extend(['/tr', server])
    args.append(file_path)
    for i in range(retries + 1):
        try:
            run(args, check=True, stdout=DEVNULL)
        except CalledProcessError:
            was_last_attempt = i == retries
            if was_last_attempt:
                raise
            else:
                sleep(sec_between_retries)
        else:
            break