from fbs import path, SETTINGS
from fbs.freeze import run_pyinstaller, _generate_resources
from fbs.resources import copy_with_filtering
from fbs_runtime._source import default_path
from os.path import join, exists
from shutil import copy

import os
import struct
import sys

def freeze_windows(debug=False):
    args = []
    if not (debug or SETTINGS['show_console_window']):
        # The --windowed flag below prevents us from seeing any console output.
        # We therefore only add it when we're not debugging.
        args.append('--windowed')
    args.extend(['--icon', path('src/main/icons/Icon.ico')])
    version_file = _create_version_info()
    args.extend(['--version-file', version_file])
    run_pyinstaller(args, debug)
    _generate_resources()
    copy(path('src/main/icons/Icon.ico'), path('${freeze_dir}'))
    _add_missing_dlls()

def _create_version_info():
    replacements = dict(SETTINGS)
    version_parts = list(map(int, SETTINGS['version'].split('.')))
    replacements['major'] = version_parts[0]
    replacements['minor'] = version_parts[1]
    replacements['build'] = version_parts[2]
    replacements['revision'] = 0 if len(version_parts) < 4 else version_parts[3]
    replacements['version_fourtuple'] = '.'.join(map(str,
        version_parts[:3] + [replacements['revision']]
    ))
    for path_fn in default_path, path:
        version_info_py = path_fn('src/freeze/windows/version_info.py')
        if exists(version_info_py):
            copy_with_filtering(
                version_info_py, path('target/PyInstaller'), replacements,
                files_to_filter=[version_info_py]
            )
            return path('target/PyInstaller/version_info.py')

def _add_missing_dlls():
    for dll_name in (
        'msvcr100.dll', 'msvcr110.dll', 'msvcp110.dll', 'vcruntime140.dll',
        'msvcp140.dll', 'concrt140.dll', 'vccorlib140.dll',
        'api-ms-win-crt-multibyte-l1-1-0.dll'
    ):
        try:
            _add_missing_dll(dll_name)
        except LookupError:
            bitness_32_or_64 = struct.calcsize("P") * 8
            raise FileNotFoundError(
                "Could not find %s on your PATH. Please install the Windows 10 "
                "SDK from "
                "https://developer.microsoft.com/en-us/windows/downloads/windows-10-sdk. "
                "Then, add the directory containing %s to your PATH "
                "environment variable. If there are 32 and 64 bit versions of "
                "the DLL, use the %s bit one (because that's the bitness of "
                "your current Python interpreter)." % (
                    dll_name, dll_name, bitness_32_or_64
                )
            ) from None

def _add_missing_dll(dll_name):
    freeze_dir = path('${freeze_dir}')
    if not exists(join(freeze_dir, dll_name)):
        copy(_find_on_path(dll_name), freeze_dir)

def _find_on_path(file_name):
    path = os.environ.get("PATH", os.defpath)
    path_items = path.split(os.pathsep)
    if sys.platform == "win32":
        if not os.curdir in path_items:
            path_items.insert(0, os.curdir)
    seen = set()
    for dir_ in path_items:
        normdir = os.path.normcase(dir_)
        if not normdir in seen:
            seen.add(normdir)
            file_path = join(dir_, file_name)
            if exists(file_path):
                return file_path
    raise LookupError("Could not find %s on PATH" % file_name)
