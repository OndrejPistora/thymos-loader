from fbs.freeze.linux import freeze_linux

def freeze_arch(debug=False):
    freeze_linux(debug)